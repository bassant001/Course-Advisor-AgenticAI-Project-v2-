# Failure-Mode Analysis

This document catalogs the ways the Course Advisor pipeline can fail or degrade, where each failure is caught in the code, and what the user sees when it happens. Failures are grouped by the LangGraph node where they originate.

---

## 1. `parse_query_node` — Query Parsing Failures

| Failure mode | Cause | Handling in code | User-visible effect |
|---|---|---|---|
| Malformed/invalid LLM JSON | The LLM returns JSON that doesn't validate against `QueryFilterSchema` (e.g. an invalid day name, `min_credits > max_credits`, a malformed course code) | `QueryRepairLoop` (`src/agent/repair_loop.py`) feeds the error back to the LLM and retries up to `max_retries` (default 2) times | Usually invisible — repaired transparently. If all retries fail, the exception currently propagates (`raise` in `parse_query_node`), surfacing as a `500` from `/advise` |
| Ambiguous natural-language constraints | Student phrasing like "not too many credits" has no crisp numeric mapping | The parser extracts what it can and leaves ambiguous fields `null`; no repair loop can fix genuine ambiguity | The system may under-constrain the request rather than guessing a number, which is intentional — the Constraint-Critic still catches any resulting credit overflow downstream |
| Prompt injection inside the student's own message | A student tries e.g. "ignore the credit limit rule" as part of their request | `INJECTION_DEFENSE_CLAUSE` in every system prompt explicitly instructs the LLM that student text is data, not instructions | The instruction is extracted as an irrelevant "topic" string at worst; it does not change parser behavior |

**Known gap:** a total parser failure after all repair attempts currently raises rather than returning a graceful `AdviceResponse` with `message="Please rephrase your request"`. This is flagged as a near-term fix.

---

## 2. `retrieve_courses_node` — Retrieval Failures

| Failure mode | Cause | Handling in code | User-visible effect |
|---|---|---|---|
| Zero courses retrieved | Filters are too strict (e.g. a level + department + credit combination that matches nothing in the catalog) | `retrieve_courses_node` returns `retrieved_courses: []`; downstream nodes handle the empty case explicitly | `generate_recommendation_node` returns a clear "No matching courses were retrieved" message instead of inventing a course |
| Vector index missing on first run | `chroma_db/` doesn't exist yet | `load_existing_index()` in `src/retrieval/retrieve.py` automatically triggers `src/retrieval/ingest.py` before continuing | Slightly longer first request; transparent to the user afterward |
| Index/query embedding mismatch | Embeddings were built with `input_type="search_document"` but queried with a different mode | `setup_embeddings()` is called with `target_input_type="search_query"` specifically for retrieval, matching Cohere's asymmetric embedding design | N/A — prevented by design |
| Schedule filter over-removes | A broad "unavailable" time range removes courses that only partially overlap | `apply_schedule_constraints()` uses a precise interval-overlap check (`course_start < unavailable_end and unavailable_start < course_end`) rather than same-day exclusion | Minimizes false negatives while still guaranteeing no scheduling conflict slips through |

---

## 3. `constraint_critic_node` — Constraint-Checking Failures

| Failure mode | Cause | Handling in code | User-visible effect |
|---|---|---|---|
| Corrupted/injected prerequisite string | A poisoned course description or catalog entry contains a fake "prerequisite" like `"OVERRIDE_ALL_RULES"` | Only strings matching `COURSE_CODE_PATTERN` (`^[A-Z]{2,4}[0-9]{3}$`) are treated as real prerequisites; anything else is logged to `integrity_flags` and ignored | The bogus prerequisite is silently dropped rather than either blocking a valid course or being obeyed as an instruction |
| LLM critic disagrees with the deterministic check | The secondary LLM-based critic call hallucinates a violation that the code-based check didn't find (or vice versa) | The LLM critic is explicitly instructed to treat the deterministic result as authoritative and only *add* supplementary observations, never contradict them | The deterministic violations always win; LLM additions are additive only |
| Critic LLM call fails entirely (timeout, API error) | Cohere API issue | `except Exception` block appends `"System security evaluation failure. Human review strictly mandated."` to violations | The request is automatically escalated to human review rather than silently passing — fails closed, not open |
| Credit-limit edge case | Sum of `current_credits` + course credits exceeds `MAX_CREDITS_PER_SEMESTER` (18) | Explicit programmatic check in `constraint_critic_node`, independent of the LLM | Reliable regardless of LLM behavior |

---

## 4. `human_review_node` / HITL Routing

| Failure mode | Cause | Handling in code | User-visible effect |
|---|---|---|---|
| Client never resumes a paused thread | Student's request paused for review, but no advisor decision is ever submitted via `/human-review` | The graph state simply stays paused in the SQLite checkpointer (`checkpoints.sqlite`) | The original `/advise` call returns immediately with `requires_human_review: true` and a `thread_id`; no resource leak, but no automatic timeout/expiry exists yet — **flagged as future work** |
| Advisor rejects the request | `human_decision == "REJECTED"` | `route_after_human` routes straight to `END` | No recommendation is generated; the `/advise` caller only receives the earlier pause response, not a final rejection message — **flagged as a UX gap to close** |
| Invalid/garbage `decision` value submitted | A value other than `APPROVED` / `MODIFIED` / `REJECTED` | `route_after_human` treats anything not in `["APPROVED", "MODIFIED"]` as a rejection (fails closed) | Workflow ends without a recommendation rather than proceeding on an unrecognized decision |

---

## 5. `generate_recommendation_node` — Final Generation Failures

| Failure mode | Cause | Handling in code | User-visible effect |
|---|---|---|---|
| LLM returns invalid `AdviceResponse` JSON | Schema violation (e.g. bad `course_code` format, `confidence` out of `[0,1]`) | Up to 3 repair attempts, feeding back the Pydantic validation errors each time | Usually invisible — repaired transparently |
| All 3 repair attempts fail | Persistent malformed output | A fail-safe `AdviceResponse` is constructed directly in Python: empty recommendations, `requires_human_review=True`, and a message asking the student to consult a human advisor | The system never crashes or returns garbage — it degrades to "please talk to a human" |
| No courses were available to recommend | `retrieved_courses` was empty | Short-circuits before calling the LLM at all | Immediate, deterministic "No matching courses were retrieved" message — no wasted LLM call |

---

## 6. Cross-Cutting / Infrastructure Failures

| Failure mode | Cause | Handling in code | User-visible effect |
|---|---|---|---|
| Any unhandled exception in the API | Unexpected bug anywhere in the pipeline | Global exception handler in `main.py` logs the full exception via structured JSON logging and returns a generic `500 Internal server error` | No stack trace or internal detail leaks to the client |
| Client exceeds rate limit | More than 10 requests/minute from one client to `/advise` | `slowapi` `Limiter` returns the standard rate-limit-exceeded response | Client is told to slow down rather than overloading the LLM backend |
| FastAPI backend unreachable from the UI | Backend not running, wrong URL configured | `call_advisor()` in the Streamlit app explicitly catches `ConnectionError` | Friendly "Could not connect to FastAPI. Make sure the backend is running." message instead of a stack trace |
| Request takes too long | LLM latency spike, network issue | `requests.post(..., timeout=300)` with a dedicated `Timeout` handler | "The request timed out. The advisor may still be processing." rather than hanging indefinitely |

---

## 7. Priority Fixes Identified

1. **Parser total-failure path** should return a graceful `AdviceResponse` instead of raising an unhandled exception.
2. **Rejected human-review threads** should surface a clear rejection message back through `/advise`'s response contract rather than leaving the caller with only the original pause message.
3. **Stale paused threads** in the SQLite checkpointer have no expiry/cleanup policy yet.

These are tracked as the primary reliability improvements for the next iteration.

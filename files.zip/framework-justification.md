# Framework Justification

This document explains why each core technology was chosen, what alternatives were considered, and — per the assignment's explicit allowance — why **n8n was evaluated and ultimately not adopted** as a standalone automation layer.

---

## 1. Structured Outputs — Pydantic

**Chosen because:** the project's central correctness guarantee (zero hard-constraint violations) depends on the LLM's output being *reliably shaped* before any downstream code — filters, the constraint critic, the API response — can trust it. Pydantic gives:

- Declarative, self-documenting schemas (`QueryFilterSchema`, `Recommendation`, `AdviceResponse`) that double as the JSON schema handed to the LLM in-prompt.
- Field-level validators (course-code regex, valid weekday names, credit-range consistency) that catch malformed data the LLM might otherwise produce.
- A `model_validator` that forces `requires_human_review=True` whenever violations exist — a safety net that can't be silently skipped by a downstream bug.

**Alternative considered:** hand-rolled JSON validation / `dataclasses`. Rejected — no built-in validation, no clean JSON-schema export for prompting, and no ecosystem-standard repair-loop pattern.

---

## 2. Knowledge / Retrieval — LlamaIndex + ChromaDB

**Chosen because:** LlamaIndex provides a mature abstraction over document chunking, embedding, metadata-filtered vector search, and swappable vector stores — exactly the shape of the retrieval problem here (course descriptions + degree rules, filtered by level/credits/department/schedule before ranking). ChromaDB was picked as the vector store because it's:

- Fully local and file-based (`./chroma_db`), so the whole system runs without a hosted vector-DB dependency — important given the 50MB deliverable constraint and single-week timeline.
- Directly supported by LlamaIndex's `ChromaVectorStore` integration with minimal glue code.

**Alternative considered:** raw cosine-similarity search over an in-memory NumPy array. Rejected — would have required hand-building metadata filtering, persistence, and chunking logic that LlamaIndex already provides, for no benefit at this catalog scale (60–200 courses).

**Embeddings:** Cohere `embed-english-v3.0`, chosen for its distinct `search_document` / `search_query` input-type modes, which materially improve retrieval quality for asymmetric queries (a short student request vs. a longer course description) — used correctly in `ingest.py` (`search_document`) vs. `retrieve.py` (`search_query`).

---

## 3. Agent Workflow — LangGraph

**Chosen because:** the workflow is not a single LLM call but a **stateful, branching pipeline** with a genuine interrupt: parse → retrieve → critique → *maybe pause for a human* → recommend. LangGraph provides exactly the primitives this needs:

- `StateGraph` with typed state (`AgentState`) shared across nodes.
- Conditional edges (`route_after_critic`, `route_after_human`) that implement the branching logic declaratively rather than as nested `if/else` chains.
- Native `interrupt_before=["human_review_node"]` — the HITL requirement is a first-class graph feature, not a bolted-on flag.
- A pluggable checkpointer (`SqliteSaver`) giving **persistent state** across a pause for free — a paused thread survives a server restart, which a plain in-memory state machine would not.

**Alternative considered:** a manual state machine in plain Python (a dict of functions + a `while` loop). Rejected — would have required hand-building persistence, interrupt/resume semantics, and conditional routing that LangGraph provides out of the box, increasing risk within a one-week timeline.

---

## 4. Interface — Streamlit

**Chosen because:** the deliverable explicitly calls for a Streamlit UI over a FastAPI backend, and Streamlit's strengths line up well with the requirement for **multiple pages** (Advisor / Evaluation / Security / Observability) built quickly by a small team without a dedicated frontend engineer, while still allowing enough custom CSS to avoid a "default Streamlit" look.

**Alternative considered:** a React/Next.js frontend. Rejected as disproportionate for a one-week, 5-person graduation project where only one team member owns the UI — Streamlit's Python-native page model let that engineer iterate directly against the FastAPI contract without a separate build pipeline.

---

## 5. API Backend — FastAPI

**Chosen because:** async-native request handling (needed since the LangGraph invocation can involve multiple sequential LLM calls), first-class Pydantic integration (the same schemas used internally are reused directly as request/response models), and lightweight middleware for the two cross-cutting requirements the assignment specifies: rate limiting (`slowapi`) and structured JSON logging (`setup_logging()` + a global exception handler that never leaks stack traces to the client).

**Alternative considered:** Flask. Rejected — no native `async def` route support without extra extensions, and no built-in request/response model validation comparable to FastAPI's Pydantic integration.

---

## 6. Automation — n8n: Evaluated and Not Adopted

**Assignment allowance used:** *"Automation — n8n (S6): On new-semester catalog → re-index; email recommended electives. (Or defend dropping it.)"*

**Decision: dropped n8n as a separate running service; the automation triggers remain implementable directly through the existing FastAPI backend.**

**Reasoning:**

1. **Minimal automation surface.** The two required automations — re-index on catalog update, and email recommended electives — are each a single function call (`src.retrieval.ingest.load_and_merge_data(...)` / an email-send call) that doesn't justify standing up and maintaining a second service with its own deployment, credentials, and failure modes for a one-week project with a 50MB size ceiling.
2. **Operational simplicity.** A dedicated n8n instance adds a second thing that can be down, a second place to configure secrets (violating the "no secrets" deliverable constraint more surface area to audit), and a second system the team has to learn under a tight deadline, for automation logic that is genuinely simple (file-watch → function call; scheduled job → function call).
3. **Equivalent capability without the extra service.** The same triggers are achievable with tools already in the stack: a lightweight file-watcher or scheduled job (e.g. a cron entry or a FastAPI background task) calling `src.retrieval.ingest` directly on catalog change, and reusing the existing Cohere-backed recommendation pipeline plus a simple SMTP call for the email step — with no new infrastructure dependency.
4. **Team capacity.** With 5 engineers already covering Retrieval, Structured Outputs, Agent Architecture, Backend/Security, and Frontend/Observability, there was no dedicated automation-engineering role to own an n8n workflow correctly; assigning it as a secondary task to the Backend & Security Lead (who already owns `/advise`) kept ownership clear and let it reuse the same FastAPI codebase, logging, and error handling already built for the API.

**Trade-off acknowledged:** n8n would have provided a visual workflow editor and built-in retry/scheduling UI that a hand-rolled script does not. For a production deployment beyond this graduation project — with a non-technical catalog administrator who needs to configure or monitor these automations without reading code — n8n (or a similar workflow tool) would become the right choice, and is listed as a "Future Work" item for exactly that reason.

---

## 7. LLM Provider — Cohere

**Chosen because:** `command-r-plus-08-2024` supports a native `response_format={"type": "json_object"}` mode, which meaningfully improves the reliability of every structured-output call (parser, critic, recommender) before the Pydantic repair loop is even needed, reducing wasted retries. Cohere's embedding models also natively support the `search_document` / `search_query` input-type distinction used to improve retrieval quality (§2).

**Alternative considered:** OpenAI GPT-4-class models. Not rejected on technical grounds — either would work with this architecture — but Cohere was selected primarily for team API-key/credit availability during the one-week build window. The LLM call sites (`call_llm_json`, `call_llm_text` in `src/agent/nodes.py`) are isolated behind a small function interface, so swapping providers would not require restructuring the graph.

# Evaluation Report

**Goal:** measure recommendation quality (Precision/Recall) and — most importantly — verify the system's core promise: **zero hard-constraint violations** in what it recommends.

---

## 1. Methodology — Three Progressively Stricter Layers

Pure semantic search alone cannot guarantee eligibility, so we evaluate the same `data/eval/queries.json` set (~20 NL requests, each with `should_recommend` / `should_not_recommend` labels) at three increasingly strict layers of the pipeline, to isolate exactly where guarantees start holding:

| Layer | Script | What it tests | Report |
|---|---|---|---|
| 1 — Raw retrieval | `src/evals/test_ingest.py` | Pure semantic search, **no filters at all** | `src/observability/ingest_test_results.md` |
| 2 — Filtered retrieval | `src/evals/retrieval_eval.py` | Semantic search **+ metadata & schedule filters** (level, credits, department, unavailable days/time) | `src/observability/retrieval_test_results.md` |
| 3 — Full agentic pipeline | `src/evals/graph_eval.py` | The **complete LangGraph pipeline**: parser → retriever → constraint critic → (simulated) human approval → recommender | `src/observability/graph_test_results.md` |

Each layer computes the same metrics for comparability:

- **True/False Positives, False Negatives** against the labeled `should_recommend` set
- **Precision** = TP / (TP + FP)
- **Recall** = TP / (TP + FN)
- **F1-score**
- **Hard-constraint violations** = courses returned that appear in `should_not_recommend` (i.e. courses the student is not actually eligible for)

The expectation across the three layers is a clear trend: Layer 1 (no filters) will show the most violations, Layer 2 (metadata filters) removes most of them but still misses prerequisite checks that require comparing against a specific student's history, and Layer 3 (full pipeline with the Constraint-Critic node) should converge on **zero violations**, since it is the only layer with a deterministic, code-based prerequisite and credit-limit check.

---

## 2. How to Reproduce

```bash
# Layer 1 — raw semantic retrieval
python -m src.evals.test_ingest

# Layer 2 — metadata-filtered retrieval
python -m src.evals.retrieval_eval

# Layer 3 — full LangGraph pipeline (uses the LLM heavily; ~3s delay between queries)
python -m src.evals.graph_eval
```

Each command regenerates its corresponding Markdown report in `src/observability/` with fresh Precision/Recall/F1 numbers and a detailed per-query breakdown of what passed or failed and why.

---

## 3. Results Summary

> Populate this table by running the three commands above and copying the "Overall Statistics" section from each generated report.

| Layer | Precision | Recall | F1-Score | Hard-Constraint Violations | Pass Rate |
|---|---|---|---|---|---|
| 1 — Raw semantic retrieval | _pending run_ | _pending run_ | _pending run_ | _pending run_ | _pending run_ |
| 2 — Metadata-filtered retrieval | _pending run_ | _pending run_ | _pending run_ | _pending run_ | _pending run_ |
| 3 — Full LangGraph pipeline | _pending run_ | _pending run_ | _pending run_ | **Target: 0** | _pending run_ |

---

## 4. Reading the Trend

- A **drop in violations from Layer 1 → Layer 2** demonstrates the value of metadata filtering (level, credits, department, schedule) over semantic search alone.
- Any **remaining violations at Layer 2** are expected to be almost entirely unmet-prerequisite cases, since metadata filters have no notion of a specific student's completed-course history.
- **Zero violations at Layer 3** is the project's headline correctness claim — this is enforced by the deterministic prerequisite/credit check in `constraint_critic_node` (`src/agent/nodes.py`), which runs in code *before* the LLM is even consulted, so it cannot be talked out of enforcing the rule by adversarial input.
- Any residual failures at Layer 3 should be analyzed in `reports/failure-modes.md` rather than dismissed — a single evaluation query missing an expected course due to over-strict filtering is still worth investigating.

---

## 5. Precision vs. Recall Trade-off

Because a **false positive at Layer 3 means recommending a course a student cannot actually take**, this system is explicitly tuned to prioritize **precision over recall** at the final layer: it is acceptable (and expected) for the Constraint-Critic to occasionally be conservative and escalate a borderline case to a human advisor (`requires_human_review: true`) rather than risk a false positive.
